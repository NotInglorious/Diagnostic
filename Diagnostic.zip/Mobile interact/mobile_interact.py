#!/usr/bin/env python3

import sys
import subprocess
import os
import urllib.request
from PyQt6.QtWidgets import (
    QApplication, QMainWindow, QWidget, QHBoxLayout, QVBoxLayout,
    QLabel, QPushButton, QFrame, QFileDialog, QMessageBox, QTabWidget,
    QLineEdit, QProgressBar, QGroupBox, QGridLayout, QStackedWidget,
    QInputDialog, QTextEdit
)
from PyQt6.QtCore import Qt, QTimer, QThread, pyqtSignal
from PyQt6.QtGui import QFont, QPixmap, QIcon, QPainter, QColor, QPen, QTextCursor

# Polished Dark Theme Styling
DARK_STYLESHEET = """
QMainWindow {
    background-color: #0F1015;
}
QWidget {
    color: #E2E8F0;
    font-family: 'Segoe UI', Ubuntu, sans-serif;
    font-size: 13px;
}
QFrame#Sidebar, QFrame#RightPanel, QFrame#MenuCard {
    background-color: #171923;
    border: 1px solid #2D3748;
    border-radius: 12px;
}
QGroupBox {
    border: 1px solid #2D3748;
    border-radius: 8px;
    margin-top: 12px;
    font-weight: bold;
    padding: 10px;
    background-color: #1A202C;
}
QGroupBox::title {
    subcontrol-origin: margin;
    left: 10px;
    padding: 0 5px;
    color: #38BDF8;
}
QLabel#DeviceHeader, QLabel#MenuTitle {
    font-size: 16px;
    font-weight: bold;
    color: #F8FAFC;
}
QPushButton {
    background-color: #1E293B;
    border: 1px solid #334155;
    border-radius: 6px;
    padding: 9px 16px;
    color: #F1F5F9;
    font-weight: 600;
}
QPushButton:hover {
    background-color: #38BDF8;
    color: #0F1015;
    border-color: #38BDF8;
}
QPushButton:pressed {
    background-color: #0284C7;
}
QPushButton#DangerBtn {
    background-color: #450A0A;
    border-color: #EF4444;
    color: #FCA5A5;
}
QPushButton#DangerBtn:hover {
    background-color: #EF4444;
    color: #FFFFFF;
}
QTabWidget::pane {
    border: 1px solid #2D3748;
    background-color: #171923;
    border-radius: 8px;
}
QTabBar::tab {
    background-color: #0F1015;
    color: #94A3B8;
    padding: 10px 22px;
    border-top-left-radius: 6px;
    border-top-right-radius: 6px;
    margin-right: 3px;
    font-weight: 500;
}
QTabBar::tab:selected {
    background-color: #171923;
    color: #38BDF8;
    font-weight: bold;
    border-bottom: 2px solid #38BDF8;
}
QLineEdit {
    background-color: #0F1015;
    border: 1px solid #334155;
    border-radius: 5px;
    padding: 7px;
    color: #F8FAFC;
}
QProgressBar {
    border: 1px solid #334155;
    border-radius: 5px;
    text-align: center;
    background-color: #0F1015;
}
QProgressBar::chunk {
    background-color: #38BDF8;
    border-radius: 4px;
}
"""

def create_default_terminal_icon():
    script_dir = os.path.dirname(os.path.abspath(__file__))
    icon_path = os.path.join(script_dir, "Terminal.png")
    if not os.path.exists(icon_path):
        pixmap = QPixmap(128, 128)
        pixmap.fill(Qt.GlobalColor.transparent)
        painter = QPainter(pixmap)
        painter.setRenderHint(QPainter.RenderHint.Antialiasing)
        painter.setBrush(QColor(23, 25, 35))
        painter.setPen(QPen(QColor(45, 55, 72), 2))
        painter.drawRoundedRect(4, 4, 120, 120, 28, 28)
        painter.setPen(QPen(QColor(148, 163, 184), 4))
        painter.setBrush(Qt.BrushStyle.NoBrush)
        painter.drawRoundedRect(20, 28, 88, 72, 12, 12)
        font = QFont("Courier New", 28, QFont.Weight.Bold)
        painter.setFont(font)
        painter.setPen(QColor(56, 189, 248))
        painter.drawText(32, 80, ">_")
        painter.end()
        pixmap.save(icon_path, "PNG")


class WorkerThread(QThread):
    finished = pyqtSignal(str)

    def __init__(self, command, capture_output=True):
        super().__init__()
        self.command = command
        self.capture_output = capture_output

    def run(self):
        try:
            if self.capture_output:
                res = subprocess.check_output(self.command, shell=True, stderr=subprocess.STDOUT)
                self.finished.emit(res.decode('utf-8', errors='ignore'))
            else:
                result = subprocess.run(self.command, shell=True, stderr=subprocess.STDOUT)
                if result.returncode == 0:
                    self.finished.emit("Storage operation completed successfully!")
                else:
                    self.finished.emit(f"Operation finished with exit code {result.returncode}.")
        except Exception as e:
            self.finished.emit(f"Error executing command: {str(e)}")


class ShellReaderThread(QThread):
    output_ready = pyqtSignal(str)

    def __init__(self, process):
        super().__init__()
        self.process = process

    def run(self):
        try:
            while True:
                line = self.process.stdout.readline()
                if not line:
                    break
                self.output_ready.emit(line)
        except Exception:
            pass


class InteractiveTerminalWidget(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(6)

        header = QLabel("Interactive Terminal Console")
        header.setStyleSheet("font-weight: bold; color: #38BDF8; font-size: 12px;")
        layout.addWidget(header)

        self.console = QTextEdit()
        self.console.setReadOnly(True)
        self.console.setStyleSheet("""
            QTextEdit {
                background-color: #0B0C10;
                color: #6EE7B7;
                font-family: 'Courier New', Courier, monospace;
                font-size: 12px;
                border: 1px solid #2D3748;
                border-top-left-radius: 6px;
                border-top-right-radius: 6px;
                padding: 8px;
            }
        """)
        layout.addWidget(self.console)

        input_layout = QHBoxLayout()
        input_layout.setContentsMargins(0, 0, 0, 0)
        input_layout.setSpacing(4)

        prompt_lbl = QLabel("$")
        prompt_lbl.setStyleSheet("color: #38BDF8; font-family: 'Courier New'; font-weight: bold; font-size: 14px;")
        input_layout.addWidget(prompt_lbl)

        self.input_line = QLineEdit()
        self.input_line.setStyleSheet("""
            QLineEdit {
                background-color: #0B0C10;
                color: #F8FAFC;
                font-family: 'Courier New', Courier, monospace;
                font-size: 12px;
                border: 1px solid #2D3748;
                border-bottom-left-radius: 6px;
                border-bottom-right-radius: 6px;
                padding: 6px;
            }
        """)
        self.input_line.setPlaceholderText("Type command (e.g., adb devices, fastboot flash...) and press Enter")
        self.input_line.returnPressed.connect(self.execute_command)
        input_layout.addWidget(self.input_line)

        layout.addLayout(input_layout)

        self.shell_process = None
        self.reader_thread = None
        self.start_shell()

    def start_shell(self):
        try:
            self.shell_process = subprocess.Popen(
                ['/bin/bash'],
                stdin=subprocess.PIPE,
                stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT,
                text=True,
                bufsize=1
            )
            self.reader_thread = ShellReaderThread(self.shell_process)
            self.reader_thread.output_ready.connect(self.append_output)
            self.reader_thread.start()
        except Exception as e:
            self.append_output(f"Failed to start interactive shell: {str(e)}\n")

    def execute_command(self):
        cmd = self.input_line.text().strip()
        if not cmd:
            return
        self.append_output(f"$ {cmd}\n")
        self.input_line.clear()
        if self.shell_process and self.shell_process.stdin:
            try:
                self.shell_process.stdin.write(cmd + "\n")
                self.shell_process.stdin.flush()
            except Exception as e:
                self.append_output(f"Error writing to shell: {str(e)}\n")

    def run_command(self, cmd):
        self.input_line.setText(cmd)
        self.execute_command()

    def append_output(self, text):
        self.console.moveCursor(QTextCursor.MoveOperation.End)
        self.console.insertPlainText(text)
        self.console.moveCursor(QTextCursor.MoveOperation.End)


class ImageDownloadWorker(QThread):
    download_finished = pyqtSignal(str)

    def __init__(self, codename, is_apple=False):
        super().__init__()
        self.codename = codename
        self.is_apple = is_apple

    def run(self):
        script_dir = os.path.dirname(os.path.abspath(__file__))
        renders_dir = os.path.join(script_dir, "Device Renders")
        os.makedirs(renders_dir, exist_ok=True)
        
        filename = f"Device render {self.codename}.png"
        filepath = os.path.join(renders_dir, filename)

        if os.path.exists(filepath):
            self.download_finished.emit(filepath)
            return

        if self.is_apple:
            url = "https://www.freepnglogos.com/uploads/apple-logo-png/apple-logo-png-0.png"
        else:
            url = "https://www.freepnglogos.com/uploads/android-logo-png/android-logo-0.png"

        try:
            req = urllib.request.Request(url, headers={'User-Agent': 'Mozilla/5.0'})
            with urllib.request.urlopen(req, timeout=6) as response, open(filepath, 'wb') as out_file:
                out_file.write(response.read())
            self.download_finished.emit(filepath)
        except Exception:
            self.download_finished.emit("")


class LogoDownloadWorker(QThread):
    logos_ready = pyqtSignal(str, str)

    def run(self):
        script_dir = os.path.dirname(os.path.abspath(__file__))
        android_logo_path = os.path.join(script_dir, "android_logo.png")
        apple_logo_path = os.path.join(script_dir, "apple_logo.png")

        if not os.path.exists(android_logo_path):
            try:
                url = "https://www.freepnglogos.com/uploads/android-logo-png/android-logo-0.png"
                req = urllib.request.Request(url, headers={'User-Agent': 'Mozilla/5.0'})
                with urllib.request.urlopen(req, timeout=5) as res, open(android_logo_path, 'wb') as f:
                    f.write(res.read())
            except Exception:
                pass

        if not os.path.exists(apple_logo_path):
            try:
                url = "https://www.freepnglogos.com/uploads/apple-logo-png/apple-logo-png-0.png"
                req = urllib.request.Request(url, headers={'User-Agent': 'Mozilla/5.0'})
                with urllib.request.urlopen(req, timeout=5) as res, open(apple_logo_path, 'wb') as f:
                    f.write(res.read())
            except Exception:
                pass

        self.logos_ready.emit(android_logo_path, apple_logo_path)


class DeviceImageViewer(QLabel):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setFixedSize(220, 340)
        self.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.setStyleSheet("background: transparent; border: none;")
        self.downloader = None
        self.display_placeholder()

    def display_placeholder(self):
        pixmap = QPixmap(200, 300)
        pixmap.fill(Qt.GlobalColor.transparent)
        self.setPixmap(pixmap)

    def load_render(self, codename, is_apple=False):
        script_dir = os.path.dirname(os.path.abspath(__file__))
        renders_dir = os.path.join(script_dir, "Device Renders")
        cached_path = os.path.join(renders_dir, f"Device render {codename}.png")

        if os.path.exists(cached_path):
            self.set_pixmap_scaled(cached_path)
        else:
            if self.downloader is not None and self.downloader.isRunning():
                return
            self.downloader = ImageDownloadWorker(codename, is_apple)
            self.downloader.download_finished.connect(self.on_download_complete)
            self.downloader.start()

    def on_download_complete(self, filepath):
        if filepath and os.path.exists(filepath):
            self.set_pixmap_scaled(filepath)

    def set_pixmap_scaled(self, path):
        pixmap = QPixmap(path)
        scaled_pixmap = pixmap.scaled(
            self.size(), 
            Qt.AspectRatioMode.KeepAspectRatio, 
            Qt.TransformationMode.SmoothTransformation
        )
        self.setPixmap(scaled_pixmap)

    def render_device(self, brand, model, connected, market_name, device_code):
        if not connected:
            self.load_render("disconnected", False)
            return
        codename = device_code if device_code and device_code != "Unknown" else "android_device"
        self.load_render(codename, False)

    def render_apple_device(self, connected, product_type):
        if not connected:
            self.load_render("apple_disconnected", True)
            return
        codename = product_type if product_type else "apple_device"
        self.load_render(codename, True)


class LandingWidget(QWidget):
    def __init__(self, select_callback):
        super().__init__()
        layout = QVBoxLayout(self)
        layout.setAlignment(Qt.AlignmentFlag.AlignCenter)
        layout.setSpacing(25)

        title = QLabel("Mobile Interact")
        title.setStyleSheet("font-size: 28px; font-weight: bold; color: #38BDF8;")
        title.setAlignment(Qt.AlignmentFlag.AlignCenter)
        layout.addWidget(title)

        subtitle = QLabel("Select a mobile platform to manage:")
        subtitle.setStyleSheet("font-size: 15px; color: #94A3B8;")
        subtitle.setAlignment(Qt.AlignmentFlag.AlignCenter)
        layout.addWidget(subtitle)

        cards_layout = QHBoxLayout()
        cards_layout.setSpacing(40)
        cards_layout.setAlignment(Qt.AlignmentFlag.AlignCenter)

        self.btn_android = QPushButton()
        self.btn_android.setFixedSize(220, 220)
        self.btn_android.setStyleSheet("""
            QPushButton {
                background-color: #171923;
                border: 2px solid #2D3748;
                border-radius: 16px;
            }
            QPushButton:hover {
                border-color: #22C55E;
                background-color: #1A202C;
            }
        """)
        self.btn_android.clicked.connect(lambda: select_callback("android"))
        cards_layout.addWidget(self.btn_android)

        self.btn_apple = QPushButton()
        self.btn_apple.setFixedSize(220, 220)
        self.btn_apple.setStyleSheet("""
            QPushButton {
                background-color: #171923;
                border: 2px solid #2D3748;
                border-radius: 16px;
            }
            QPushButton:hover {
                border-color: #38BDF8;
                background-color: #1A202C;
            }
        """)
        self.btn_apple.clicked.connect(lambda: select_callback("apple"))
        cards_layout.addWidget(self.btn_apple)

        layout.addLayout(cards_layout)

        self.logo_worker = LogoDownloadWorker()
        self.logo_worker.logos_ready.connect(self.apply_menu_logos)
        self.logo_worker.start()

    def apply_menu_logos(self, android_path, apple_path):
        if os.path.exists(android_path):
            self.btn_android.setIcon(QIcon(android_path))
            self.btn_android.setIconSize(QPixmap(android_path).scaled(140, 140, Qt.AspectRatioMode.KeepAspectRatio, Qt.TransformationMode.SmoothTransformation).size())
        if os.path.exists(apple_path):
            self.btn_apple.setIcon(QIcon(apple_path))
            self.btn_apple.setIconSize(QPixmap(apple_path).scaled(140, 140, Qt.AspectRatioMode.KeepAspectRatio, Qt.TransformationMode.SmoothTransformation).size())


class AndroidWidget(QWidget):
    def __init__(self, back_callback):
        super().__init__()
        layout = QHBoxLayout(self)
        layout.setContentsMargins(12, 12, 12, 12)
        layout.setSpacing(12)

        self.back_callback = back_callback
        self.worker = None
        self.current_codename = "unknown_device"
        self.setup_sidebar(layout)
        self.setup_tabs(layout)
        self.setup_right_panel(layout)

        self.timer = QTimer()
        self.timer.timeout.connect(self.update_device_info)
        self.timer.start(3000)
        self.update_device_info()

    def get_active_serial(self):
        try:
            out = subprocess.check_output("adb devices", shell=True).decode().strip()
            lines = [line.split()[0] for line in out.split('\n') if '\tdevice' in line]
            return lines[0] if lines else None
        except:
            return None

    def setup_sidebar(self, parent_layout):
        sidebar = QFrame()
        sidebar.setObjectName("Sidebar")
        layout = QVBoxLayout(sidebar)
        layout.setContentsMargins(15, 15, 15, 15)
        layout.setSpacing(10)

        title = QLabel("Android Diagnostics")
        title.setObjectName("DeviceHeader")
        layout.addWidget(title)

        self.lbl_status = QLabel("Searching...")
        self.lbl_status.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.lbl_status.setStyleSheet("background-color: #334155; color: #F1F5F9; padding: 6px; border-radius: 6px; font-weight: bold;")
        layout.addWidget(self.lbl_status)

        self.info_model = QLabel("Model Name: --")
        self.info_number = QLabel("Model Code: --")
        self.info_brand = QLabel("Brand: --")
        self.info_android = QLabel("Android Version: --")
        self.info_cpu = QLabel("CPU Architecture: --")
        self.info_ram = QLabel("Total RAM: --")

        self.info_batt_lvl = QLabel("Battery Level: --")
        self.info_batt_health = QLabel("Battery Health: --")
        self.info_charge_state = QLabel("Charging State: --")
        self.info_temp = QLabel("Temperature: --")

        hw_group = QGroupBox("Hardware Specs")
        hw_box = QVBoxLayout(hw_group)
        hw_box.addWidget(self.info_brand)
        hw_box.addWidget(self.info_model)
        hw_box.addWidget(self.info_number)
        hw_box.addWidget(self.info_android)
        hw_box.addWidget(self.info_cpu)
        hw_box.addWidget(self.info_ram)
        layout.addWidget(hw_group)

        batt_group = QGroupBox("Battery & Power")
        batt_box = QVBoxLayout(batt_group)
        batt_box.addWidget(self.info_batt_lvl)
        batt_box.addWidget(self.info_batt_health)
        batt_box.addWidget(self.info_charge_state)
        batt_box.addWidget(self.info_temp)
        layout.addWidget(batt_group)

        layout.addStretch()

        btn_refresh = QPushButton("Manual Refresh")
        btn_refresh.clicked.connect(self.update_device_info)
        layout.addWidget(btn_refresh)

        btn_back = QPushButton("⬅ Main Menu")
        btn_back.clicked.connect(self.back_callback)
        layout.addWidget(btn_back)

        parent_layout.addWidget(sidebar, 1)

    def setup_tabs(self, parent_layout):
        tab_container = QWidget()
        container_layout = QVBoxLayout(tab_container)
        container_layout.setContentsMargins(0, 0, 0, 0)

        tabs = QTabWidget()
        
        tab_reboot = QWidget()
        r_layout = QGridLayout(tab_reboot)
        r_layout.setSpacing(15)

        btn_reb_sys = QPushButton("System Reboot")
        btn_reb_rec = QPushButton("Recovery Mode")
        btn_reb_fast = QPushButton("Bootloader / Fastboot")
        btn_reb_edl = QPushButton("EDL Mode (Qualcomm)")
        btn_reb_sam = QPushButton("Download Mode (Samsung)")

        btn_reb_sys.clicked.connect(lambda: self.run_cmd("reboot"))
        btn_reb_rec.clicked.connect(lambda: self.run_cmd("reboot recovery"))
        btn_reb_fast.clicked.connect(lambda: self.run_cmd("reboot bootloader"))
        btn_reb_edl.clicked.connect(lambda: self.run_cmd("reboot edl"))
        btn_reb_sam.clicked.connect(lambda: self.run_cmd("reboot download"))

        r_layout.addWidget(btn_reb_sys, 0, 0)
        r_layout.addWidget(btn_reb_rec, 0, 1)
        r_layout.addWidget(btn_reb_fast, 1, 0)
        r_layout.addWidget(btn_reb_edl, 1, 1)
        r_layout.addWidget(btn_reb_sam, 2, 0, 1, 2)
        r_layout.setRowStretch(3, 1)

        tab_backup = QWidget()
        b_layout = QVBoxLayout(tab_backup)
        b_layout.setSpacing(15)

        btn_pull_sdcard = QPushButton("Pull Entire Internal Storage (/sdcard) to PC")
        btn_pull_custom = QPushButton("Pull Specific Path from Connected Device")
        btn_legacy_backup = QPushButton("Legacy ADB App Data Backup")

        btn_pull_sdcard.clicked.connect(self.action_pull_sdcard)
        btn_pull_custom.clicked.connect(self.action_pull_custom)
        btn_legacy_backup.clicked.connect(self.action_legacy_backup)

        b_layout.addWidget(btn_pull_sdcard)
        b_layout.addWidget(btn_pull_custom)
        b_layout.addWidget(btn_legacy_backup)
        b_layout.addStretch()

        tab_flash = QWidget()
        f_layout = QVBoxLayout(tab_flash)
        f_layout.setSpacing(12)

        flash_buttons_layout = QHBoxLayout()
        btn_flash_img = QPushButton("Flash Image (.img) via Fastboot")
        btn_flash_img.setObjectName("DangerBtn")
        
        btn_unlock_bl = QPushButton("Unlock Bootloader (Fastboot)")
        btn_unlock_bl.setObjectName("DangerBtn")
        btn_unlock_bl.clicked.connect(self.action_unlock_bootloader)

        btn_sideload = QPushButton("Sideload OTA / Update ZIP")

        btn_flash_img.clicked.connect(self.action_flash_partition)
        btn_sideload.clicked.connect(self.action_sideload)

        flash_buttons_layout.addWidget(btn_flash_img)
        flash_buttons_layout.addWidget(btn_unlock_bl)
        flash_buttons_layout.addWidget(btn_sideload)
        f_layout.addLayout(flash_buttons_layout)

        self.android_terminal = InteractiveTerminalWidget()
        f_layout.addWidget(self.android_terminal, 1)

        tabs.addTab(tab_reboot, "Reboot Options")
        tabs.addTab(tab_backup, "Data Recovery & Backup")
        tabs.addTab(tab_flash, "Flashing & Updates")

        container_layout.addWidget(tabs)

        self.progress = QProgressBar()
        self.progress.setTextVisible(False)
        self.progress.setFixedHeight(6)
        self.progress.setValue(0)
        container_layout.addWidget(self.progress)

        parent_layout.addWidget(tab_container, 2)

    def setup_right_panel(self, parent_layout):
        right_panel = QFrame()
        right_panel.setObjectName("RightPanel")
        layout = QVBoxLayout(right_panel)
        layout.setContentsMargins(15, 15, 15, 15)
        layout.setAlignment(Qt.AlignmentFlag.AlignCenter)

        title = QLabel("Device Render")
        title.setObjectName("DeviceHeader")
        layout.addWidget(title)

        self.device_image_viewer = DeviceImageViewer()
        layout.addWidget(self.device_image_viewer, alignment=Qt.AlignmentFlag.AlignCenter)

        btn_export = QPushButton("Export Transparent PNG")
        btn_export.clicked.connect(self.export_render)
        layout.addWidget(btn_export)

        layout.addStretch()
        parent_layout.addWidget(right_panel, 1)

    def export_render(self):
        pixmap = self.device_image_viewer.pixmap()
        if pixmap and not pixmap.isNull():
            script_dir = os.path.dirname(os.path.abspath(__file__))
            renders_dir = os.path.join(script_dir, "Device Renders")
            os.makedirs(renders_dir, exist_ok=True)
            
            filename = f"Device render {self.current_codename}.png"
            path = os.path.join(renders_dir, filename)
            
            pixmap.save(path, "PNG")
            QMessageBox.information(self, "Export Successful", f"Transparent render saved to:\n{path}")
        else:
            QMessageBox.warning(self, "No Render Available", "No device graphic is currently loaded to export.")

    def run_cmd(self, cmd, is_fastboot=False, capture_output=True):
        if self.worker is not None and self.worker.isRunning():
            QMessageBox.warning(self, "Operation in Progress", "Please wait for the current task to finish.")
            return

        serial = self.get_active_serial()
        target_prefix = f"adb -s {serial}" if not is_fastboot else "fastboot"
        full_command = f"{target_prefix} {cmd}"
        
        self.progress.setMinimum(0)
        self.progress.setMaximum(0)
        self.worker = WorkerThread(full_command, capture_output=capture_output)
        self.worker.finished.connect(self.cmd_finished)
        self.worker.start()

    def cmd_finished(self, result):
        self.progress.setMinimum(0)
        self.progress.setMaximum(100)
        self.progress.setValue(100)
        QMessageBox.information(self, "Execution Result", f"Output:\n{result.strip()}")
        self.progress.setValue(0)
        self.worker = None

    def update_device_info(self):
        serial = self.get_active_serial()
        if not serial:
            self.lbl_status.setText("Disconnected")
            self.lbl_status.setStyleSheet("background-color: #450A0A; color: #FCA5A5; padding: 6px; border-radius: 6px; font-weight: bold;")
            self.info_brand.setText("Brand: --")
            self.info_model.setText("Model Name: --")
            self.info_number.setText("Model Code: --")
            self.info_android.setText("Android Version: --")
            self.info_cpu.setText("CPU Architecture: --")
            self.info_ram.setText("Total RAM: --")
            self.info_batt_lvl.setText("Battery Level: --")
            self.info_batt_health.setText("Battery Health: --")
            self.info_charge_state.setText("Charging State: --")
            self.info_temp.setText("Temperature: --")
            self.current_codename = "disconnected"
            self.device_image_viewer.render_device("", "", False, "", "")
            return

        self.lbl_status.setText(f"Connected ({serial})")
        self.lbl_status.setStyleSheet("background-color: #065F46; color: #6EE7B7; padding: 6px; border-radius: 6px; font-weight: bold;")

        def get_prop(prop):
            try:
                return subprocess.check_output(f"adb -s {serial} shell getprop {prop}", shell=True).decode().strip()
            except:
                return "Unknown"

        brand = get_prop('ro.product.brand').capitalize()
        model = get_prop('ro.product.model')
        market_name = get_prop('ro.product.marketname')
        code = get_prop('ro.product.device')
        
        self.current_codename = code if code != "Unknown" else "android_device"

        self.info_brand.setText(f"Brand: {brand}")
        self.info_model.setText(f"Model Name: {model}")
        self.info_number.setText(f"Model Code: {code}")
        self.info_android.setText(f"Android Version: {get_prop('ro.build.version.release')}")
        self.info_cpu.setText(f"CPU Architecture: {get_prop('ro.product.cpu.abi')}")

        self.device_image_viewer.render_device(brand, model, True, market_name, code)

        try:
            ram_kb = subprocess.check_output(f"adb -s {serial} shell grep MemTotal /proc/meminfo", shell=True).decode().split()[1]
            ram_gb = round(int(ram_kb) / 1024 / 1024, 2)
            self.info_ram.setText(f"Total RAM: {ram_gb} GB")
        except:
            self.info_ram.setText("Total RAM: Unknown")

        try:
            batt = subprocess.check_output(f"adb -s {serial} shell dumpsys battery", shell=True).decode()
            level = [line.split(":")[1].strip() for line in batt.split("\n") if "level:" in line][0].strip()
            temp_raw = [line.split(":")[1].strip() for line in batt.split("\n") if "temperature:" in line][0].strip()
            temp = f"{int(temp_raw) / 10:.1f}°C"

            health_code = [line.split(":")[1].strip() for line in batt.split("\n") if "health:" in line][0].strip()
            health_map = {"1": "Unknown", "2": "Good", "3": "Overheat", "4": "Dead", "5": "Over Voltage", "6": "Failure", "7": "Cold"}
            health_text = health_map.get(health_code, f"Code {health_code}")

            state = "Discharging"
            if "AC powered: true" in batt: state = "Charging (AC)"
            elif "USB powered: true" in batt: state = "Charging (USB)"
            elif "Wireless powered: true" in batt: state = "Charging (Wireless)"

            self.info_batt_lvl.setText(f"Battery Level: {level}%")
            self.info_batt_health.setText(f"Battery Health: {health_text}")
            self.info_charge_state.setText(f"Charging State: {state}")
            self.info_temp.setText(f"Temperature: {temp}")
        except:
            pass

    def action_pull_sdcard(self):
        serial = self.get_active_serial()
        if not serial:
            QMessageBox.warning(self, "No Device", "No active Android device detected.")
            return
        dest = QFileDialog.getExistingDirectory(self, "Select PC Backup Folder")
        if dest:
            QMessageBox.information(self, "Pull Started", "Pulling storage in background. The app will notify you when complete.")
            self.run_cmd(f"pull /sdcard '{dest}'", capture_output=False)

    def action_pull_custom(self):
        serial = self.get_active_serial()
        if not serial:
            QMessageBox.warning(self, "No Device", "No active Android device detected.")
            return
        dev_path, ok1 = QInputDialog.getText(self, "Path on Device", "Enter device file/folder path (e.g. /sdcard/Download):", text="/sdcard/Download")
        if ok1 and dev_path:
            pc_path = QFileDialog.getExistingDirectory(self, "Select PC Destination Directory")
            if pc_path:
                QMessageBox.information(self, "Pull Started", "Pulling files in background. The app will notify you when complete.")
                self.run_cmd(f"pull '{dev_path}' '{pc_path}'", capture_output=False)

    def action_legacy_backup(self):
        serial = self.get_active_serial()
        if not serial:
            QMessageBox.warning(self, "No Device", "No active Android device detected.")
            return
        name, ok = QInputDialog.getText(self, "Backup File", "Enter backup filename:", text="backup.ab")
        if ok and name:
            QMessageBox.warning(self, "Device Confirmation Needed", "Unlock your phone screen and tap 'Back up my data'.")
            self.run_cmd(f"backup -all -f '{name}'", capture_output=False)

    def action_flash_partition(self):
        partition, ok = QInputDialog.getText(self, "Target Partition", "Partition to flash (boot, recovery, vbmeta, system):", text="boot")
        if ok and partition:
            img_path, _ = QFileDialog.getOpenFileName(self, "Select Image File", "", "Image Files (*.img)")
            if img_path:
                confirm = QMessageBox.question(
                    self, "Confirm Dangerous Operation",
                    f"CRITICAL WARNING:\nAre you sure you want to flash:\n{os.path.basename(img_path)}\n\nTo partition: {partition}?",
                    QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No
                )
                if confirm == QMessageBox.StandardButton.Yes:
                    full_cmd = f"fastboot flash {partition} '{img_path}'"
                    self.android_terminal.run_command(full_cmd)

    def action_unlock_bootloader(self):
        confirm = QMessageBox.question(
            self, "CRITICAL WARNING: Unlock Bootloader",
            "WARNING: Unlocking the bootloader will ERASE ALL USER DATA on your device and may void your warranty!\n\nEnsure your device is in Fastboot mode and OEM Unlocking is enabled in Developer Options.\n\nProceed?",
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No
        )
        if confirm == QMessageBox.StandardButton.Yes:
            choice, ok = QInputDialog.getItem(
                self, "Select Fastboot Unlock Command", 
                "Choose unlock method:", 
                ["fastboot flashing unlock", "fastboot oem unlock"], 
                0, False
            )
            if ok and choice:
                self.android_terminal.run_command(choice)

    def action_sideload(self):
        serial = self.get_active_serial()
        if not serial:
            QMessageBox.warning(self, "No Device", "No active Android device detected.")
            return
        zip_path, _ = QFileDialog.getOpenFileName(self, "Select Package File", "", "ZIP Files (*.zip)")
        if zip_path:
            full_cmd = f"adb -s {serial} sideload '{zip_path}'"
            self.android_terminal.run_command(full_cmd)


class AppleWidget(QWidget):
    def __init__(self, back_callback):
        super().__init__()
        layout = QHBoxLayout(self)
        layout.setContentsMargins(12, 12, 12, 12)
        layout.setSpacing(12)

        self.back_callback = back_callback
        self.worker = None
        self.current_product_type = "unknown_ios_device"
        self.setup_apple_sidebar(layout)
        self.setup_apple_tabs(layout)
        self.setup_apple_right_panel(layout)

        self.ensure_usbmuxd_running()

        self.timer = QTimer()
        self.timer.timeout.connect(self.update_apple_info)
        self.timer.start(3000)
        self.update_apple_info()

    def ensure_usbmuxd_running(self):
        try:
            status = subprocess.run("systemctl is-active usbmuxd", shell=True, capture_output=True, text=True).stdout.strip()
            if status != "active":
                subprocess.run("sudo systemctl start usbmuxd", shell=True, capture_output=True)
        except Exception:
            pass

    def get_active_udid(self):
        try:
            dev_list = subprocess.check_output("idevice_id -l", shell=True).decode().strip()
            lines = [l.strip() for l in dev_list.split('\n') if l.strip()]
            return lines[0] if lines else None
        except:
            return None

    def setup_apple_sidebar(self, parent_layout):
        sidebar = QFrame()
        sidebar.setObjectName("Sidebar")
        layout = QVBoxLayout(sidebar)
        layout.setContentsMargins(15, 15, 15, 15)
        layout.setSpacing(10)

        title = QLabel("Apple Diagnostics")
        title.setObjectName("DeviceHeader")
        layout.addWidget(title)

        self.lbl_apple_status = QLabel("Searching...")
        self.lbl_apple_status.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.lbl_apple_status.setStyleSheet("background-color: #334155; color: #F1F5F9; padding: 6px; border-radius: 6px; font-weight: bold;")
        layout.addWidget(self.lbl_apple_status)

        self.apple_product = QLabel("Device: --")
        self.apple_ios = QLabel("iOS Version: --")
        self.apple_ecid = QLabel("ECID / UDID: --")
        self.apple_mode = QLabel("Connection Mode: --")

        info_group = QGroupBox("iOS Device Info")
        info_box = QVBoxLayout(info_group)
        info_box.addWidget(self.apple_product)
        info_box.addWidget(self.apple_ios)
        info_box.addWidget(self.apple_ecid)
        info_box.addWidget(self.apple_mode)
        layout.addWidget(info_group)

        layout.addStretch()

        btn_refresh = QPushButton("Manual Refresh")
        btn_refresh.clicked.connect(self.update_apple_info)
        layout.addWidget(btn_refresh)

        btn_back = QPushButton("⬅ Main Menu")
        btn_back.clicked.connect(self.back_callback)
        layout.addWidget(btn_back)

        parent_layout.addWidget(sidebar, 1)

    def setup_apple_tabs(self, parent_layout):
        tab_container = QWidget()
        container_layout = QVBoxLayout(tab_container)
        container_layout.setContentsMargins(0, 0, 0, 0)

        tabs = QTabWidget()
        
        tab_modes = QWidget()
        m_layout = QGridLayout(tab_modes)
        m_layout.setSpacing(15)

        btn_recovery = QPushButton("Enter Recovery Mode")
        btn_dfu = QPushButton("Put Device into DFU Mode Guide")
        btn_exit_rec = QPushButton("Exit Recovery / Reboot Normal")

        btn_recovery.clicked.connect(self.action_enter_recovery)
        btn_dfu.clicked.connect(self.show_dfu_guide)
        btn_exit_rec.clicked.connect(lambda: self.run_apple_cmd("irecovery -n"))

        m_layout.addWidget(btn_recovery, 0, 0)
        m_layout.addWidget(btn_dfu, 0, 1)
        m_layout.addWidget(btn_exit_rec, 1, 0, 1, 2)
        m_layout.setRowStretch(2, 1)

        tab_backup = QWidget()
        b_layout = QVBoxLayout(tab_backup)
        b_layout.setSpacing(15)

        btn_backup_ios = QPushButton("Backup Connected iOS Device (Full Backup)")
        btn_pull_app_data = QPushButton("Pull App Documents / Sandbox Storage")
        
        btn_backup_ios.clicked.connect(self.action_apple_full_backup)
        btn_pull_app_data.clicked.connect(self.action_apple_pull_apps)

        b_layout.addWidget(btn_backup_ios)
        b_layout.addWidget(btn_pull_app_data)
        b_layout.addStretch()

        tab_flash = QWidget()
        f_layout = QVBoxLayout(tab_flash)
        f_layout.setSpacing(12)

        apple_flash_buttons = QHBoxLayout()
        btn_flash_ipsw = QPushButton("Flash Official Firmware (.ipsw)")
        btn_flash_ipsw.setObjectName("DangerBtn")
        btn_make_dfu_ipsw = QPushButton("Make Custom DFU IPSW Package")

        btn_flash_ipsw.clicked.connect(self.action_flash_ipsw)
        btn_make_dfu_ipsw.clicked.connect(self.action_make_dfu_ipsw)

        apple_flash_buttons.addWidget(btn_flash_ipsw)
        apple_flash_buttons.addWidget(btn_make_dfu_ipsw)
        f_layout.addLayout(apple_flash_buttons)

        self.apple_terminal = InteractiveTerminalWidget()
        f_layout.addWidget(self.apple_terminal, 1)

        tab_jb = QWidget()
        j_layout = QVBoxLayout(tab_jb)
        j_layout.setSpacing(15)

        btn_palera1n = QPushButton("Launch Palera1n Jailbreak Helper")
        btn_checkra1n = QPushButton("Checkra1n DFU Exploit Mode")

        btn_palera1n.clicked.connect(lambda: QMessageBox.information(self, "Jailbreak Helper", "Ensure device is in DFU/Recovery mode, then execute checkra1n/palera1n externally."))
        btn_checkra1n.clicked.connect(lambda: QMessageBox.information(self, "DFU Exploit", "Preparing checkra1n hook environment..."))

        j_layout.addWidget(btn_palera1n)
        j_layout.addWidget(btn_checkra1n)
        j_layout.addStretch()

        tabs.addTab(tab_modes, "Recovery & DFU")
        tabs.addTab(tab_backup, "Data Recovery & Backup")
        tabs.addTab(tab_flash, "IPSW & Firmware")
        tabs.addTab(tab_jb, "Jailbreak Tools")

        container_layout.addWidget(tabs)

        self.apple_progress = QProgressBar()
        self.apple_progress.setTextVisible(False)
        self.apple_progress.setFixedHeight(6)
        self.apple_progress.setValue(0)
        container_layout.addWidget(self.apple_progress)

        parent_layout.addWidget(tab_container, 2)

    def setup_apple_right_panel(self, parent_layout):
        right_panel = QFrame()
        right_panel.setObjectName("RightPanel")
        layout = QVBoxLayout(right_panel)
        layout.setContentsMargins(15, 15, 15, 15)
        layout.setAlignment(Qt.AlignmentFlag.AlignCenter)

        title = QLabel("Device Render")
        title.setObjectName("DeviceHeader")
        layout.addWidget(title)

        self.apple_device_image_viewer = DeviceImageViewer()
        layout.addWidget(self.apple_device_image_viewer, alignment=Qt.AlignmentFlag.AlignCenter)

        btn_export = QPushButton("Export Transparent PNG")
        btn_export.clicked.connect(self.export_render)
        layout.addWidget(btn_export)

        layout.addStretch()
        parent_layout.addWidget(right_panel, 1)

    def export_render(self):
        pixmap = self.apple_device_image_viewer.pixmap()
        if pixmap and not pixmap.isNull():
            script_dir = os.path.dirname(os.path.abspath(__file__))
            renders_dir = os.path.join(script_dir, "Device Renders")
            os.makedirs(renders_dir, exist_ok=True)
            
            filename = f"Device render {self.current_product_type}.png"
            path = os.path.join(renders_dir, filename)
            
            pixmap.save(path, "PNG")
            QMessageBox.information(self, "Export Successful", f"Transparent render saved to:\n{path}")
        else:
            QMessageBox.warning(self, "No Render Available", "No device graphic is currently loaded to export.")

    def run_apple_cmd(self, cmd, capture_output=True):
        if self.worker is not None and self.worker.isRunning():
            QMessageBox.warning(self, "Operation in Progress", "Please wait for the current task to finish.")
            return

        self.apple_progress.setMinimum(0)
        self.apple_progress.setMaximum(0)
        self.worker = WorkerThread(cmd, capture_output=capture_output)
        self.worker.finished.connect(self.apple_cmd_finished)
        self.worker.start()

    def apple_cmd_finished(self, result):
        self.apple_progress.setMinimum(0)
        self.apple_progress.setMaximum(100)
        self.apple_progress.setValue(100)
        QMessageBox.information(self, "Apple Execution Result", f"Output:\n{result.strip()}")
        self.apple_progress.setValue(0)
        self.worker = None

    def action_enter_recovery(self):
        udid = self.get_active_udid()
        if not udid:
            QMessageBox.warning(self, "No Device", "No connected iOS device detected.")
            return
        self.run_apple_cmd(f"ideviceenterrecovery {udid}")

    def action_apple_full_backup(self):
        udid = self.get_active_udid()
        if not udid:
            QMessageBox.warning(self, "No Device", "No connected iOS device detected.")
            return
        dest = QFileDialog.getExistingDirectory(self, "Select Backup Destination Folder on PC")
        if dest:
            QMessageBox.information(self, "Backup Started", "Running full iOS backup in background. This may take a while.")
            self.run_apple_cmd(f"idevicebackup2 --udid {udid} backup '{dest}'", capture_output=False)

    def action_apple_pull_apps(self):
        udid = self.get_active_udid()
        if not udid:
            QMessageBox.warning(self, "No Device", "No connected iOS device detected.")
            return
        dest = QFileDialog.getExistingDirectory(self, "Select Folder to Save App Archives")
        if dest:
            QMessageBox.information(self, "Backup Started", "Retrieving app sandbox archives in background.")
            self.run_apple_cmd(f"idevicebackup2 --udid {udid} backup '{dest}'", capture_output=False)

    def show_dfu_guide(self):
        QMessageBox.information(
            self, "DFU Mode Entry Guide",
            "To enter DFU mode manually:\n\n"
            "1. Connect your device via USB to the PC.\n"
            "2. Press and quickly release Volume Up.\n"
            "3. Press and quickly release Volume Down.\n"
            "4. Press and hold the Side/Power button until the screen goes black.\n"
            "5. While holding Power, press and hold Volume Down for 5 seconds.\n"
            "6. Release Power but continue holding Volume Down until recognized in DFU."
        )

    def action_flash_ipsw(self):
        udid = self.get_active_udid()
        ipsw_path, _ = QFileDialog.getOpenFileName(self, "Select IPSW Firmware", "", "IPSW Files (*.ipsw)")
        if ipsw_path:
            confirm = QMessageBox.question(self, "Confirm IPSW Restore", f"Flash firmware to connected device?\n{os.path.basename(ipsw_path)}?", QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No)
            if confirm == QMessageBox.StandardButton.Yes:
                cmd = f"idevicerestore -d '{ipsw_path}'"
                if udid:
                    cmd = f"idevicerestore -u {udid} -d '{ipsw_path}'"
                self.apple_terminal.run_command(cmd)

    def action_make_dfu_ipsw(self):
        QMessageBox.information(self, "Custom DFU IPSW", "Select base IPSW to patch signature parameters for custom DFU execution.")
        ipsw_path, _ = QFileDialog.getOpenFileName(self, "Select Base IPSW", "", "IPSW Files (*.ipsw)")
        if ipsw_path:
            QMessageBox.information(self, "Success", f"Custom DFU workspace initialized for: {os.path.basename(ipsw_path)}")

    def update_apple_info(self):
        udid = self.get_active_udid()
        if not udid:
            self.lbl_apple_status.setText("No Apple Device")
            self.lbl_apple_status.setStyleSheet("background-color: #450A0A; color: #FCA5A5; padding: 6px; border-radius: 6px; font-weight: bold;")
            self.apple_product.setText("Device: --")
            self.apple_ios.setText("iOS Version: --")
            self.apple_ecid.setText("ECID / UDID: --")
            self.apple_mode.setText("Connection Mode: Disconnected")
            self.current_product_type = "disconnected"
            self.apple_device_image_viewer.render_apple_device(False, "")
            return

        try:
            subprocess.run(f"idevicepair --udid {udid} validate", shell=True, capture_output=True, check=True)
        except subprocess.CalledProcessError:
            try:
                subprocess.run(f"idevicepair --udid {udid} pair", shell=True, capture_output=True)
            except Exception:
                pass

        self.lbl_apple_status.setText(f"Connected ({udid[:8]}...)")
        self.lbl_apple_status.setStyleSheet("background-color: #065F46; color: #6EE7B7; padding: 6px; border-radius: 6px; font-weight: bold;")

        try:
            prod_name = subprocess.check_output(f"ideviceinfo --udid {udid} -k ProductType", shell=True).decode().strip()
            ios_ver = subprocess.check_output(f"ideviceinfo --udid {udid} -k ProductVersion", shell=True).decode().strip()
            
            self.current_product_type = prod_name if prod_name else "ios_device"

            self.apple_product.setText(f"Device: {prod_name}")
            self.apple_ios.setText(f"iOS Version: {ios_ver}")
            self.apple_ecid.setText(f"UDID: {udid[:12]}...")
            self.apple_mode.setText("Connection Mode: Normal / Activated")
            self.apple_device_image_viewer.render_apple_device(True, prod_name)
        except:
            self.apple_mode.setText("Connection Mode: Unlock Screen / Trust PC")
            self.apple_device_image_viewer.render_apple_device(True, "")


class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Mobile Interact (Multi-Platform)")
        self.resize(1150, 620)
        self.setStyleSheet(DARK_STYLESHEET)
        
        script_dir = os.path.dirname(os.path.abspath(__file__))
        icon_path = os.path.join(script_dir, "Terminal.png")
        if os.path.exists(icon_path):
            app_icon = QIcon(icon_path)
            self.setWindowIcon(app_icon)
            QApplication.setWindowIcon(app_icon)
        
        self.create_desktop_shortcut()

        self.stack = QStackedWidget()
        self.setCentralWidget(self.stack)

        self.landing_widget = LandingWidget(self.switch_ecosystem)
        self.android_widget = AndroidWidget(self.return_to_landing)
        self.apple_widget = AppleWidget(self.return_to_landing)

        self.stack.addWidget(self.landing_widget)
        self.stack.addWidget(self.android_widget)
        self.stack.addWidget(self.apple_widget)

        self.stack.setCurrentWidget(self.landing_widget)

    def switch_ecosystem(self, target):
        if target == "android":
            self.stack.setCurrentWidget(self.android_widget)
        elif target == "apple":
            self.stack.setCurrentWidget(self.apple_widget)

    def return_to_landing(self):
        self.stack.setCurrentWidget(self.landing_widget)

    def create_desktop_shortcut(self):
        desktop_dir = os.path.expanduser("~/.local/share/applications")
        os.makedirs(desktop_dir, exist_ok=True)
        script_path = os.path.abspath(__file__)
        script_dir = os.path.dirname(script_path)
        icon_path = os.path.join(script_dir, "Terminal.png")
        
        try:
            os.chmod(script_path, 0o755)
        except Exception:
            pass

        desktop_file_path = os.path.join(desktop_dir, "mobile-interact.desktop")
        
        desktop_entry = f"""[Desktop Entry]
Type=Application
Name=Mobile Interact
Comment=Manage Android and Apple iOS Devices
Exec=/usr/bin/python3 "{script_path}"
Icon={icon_path}
Terminal=false
Categories=Development;Utility;
StartupWMClass=mobile-interact
"""
        try:
            with open(desktop_file_path, "w") as f:
                f.write(desktop_entry)
            os.chmod(desktop_file_path, 0o755)
            subprocess.run(["update-desktop-database", desktop_dir], capture_output=True)
        except Exception:
            pass


if __name__ == "__main__":
    app = QApplication(sys.argv)
    
    # Bind desktop filename for Linux window manager / WM_CLASS icon matching
    if hasattr(app, "setDesktopFileName"):
        app.setDesktopFileName("mobile-interact")

    create_default_terminal_icon()
    
    script_dir = os.path.dirname(os.path.abspath(__file__))
    icon_path = os.path.join(script_dir, "Terminal.png")
    if os.path.exists(icon_path):
        app_icon = QIcon(icon_path)
        app.setWindowIcon(app_icon)
        
    window = MainWindow()
    if os.path.exists(icon_path):
        window.setWindowIcon(QIcon(icon_path))
        
    window.show()
    sys.exit(app.exec())
